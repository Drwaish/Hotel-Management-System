/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author TOSHIBA Z30
 */
public class InsertUpdateDelete {
    
    public static void setdata(String Query,String msg)
    {
    Statement st=null;
    Connection con=null;
    try{
      con=ConnectionProvider.getcon();
       st=(Statement)con.createStatement();
       // System.out.println(Query);
       st.executeUpdate(Query);
     
     
       if(msg.equalsIgnoreCase(" "))
           JOptionPane.showMessageDialog(null, msg);
        
        
        
      }
    catch(Exception e)
       {
        
        JOptionPane.showMessageDialog(null,msg);
        
       }
    finally{
        
     try{
       
        con.close();
      }
    catch(Exception e)
       {
        
        
        
       }
        
    }
    }
    
}
