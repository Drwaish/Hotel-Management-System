/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author TOSHIBA Z30
 */
public class Get {
    public static ResultSet getdata(String Query)
    {
        Connection con=null;
        ResultSet rs=null;
        Statement st=null;
        try{
        
            con=ConnectionProvider.getcon();
            st=con.createStatement();
            rs=st.executeQuery(Query);
            //if(rs.next())
            //System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
          return rs;
        }
        catch(Exception e)
        {
            
        JOptionPane.showMessageDialog(null, "Error while loading data");
        
        }
        
        return null;
    }
    
}
