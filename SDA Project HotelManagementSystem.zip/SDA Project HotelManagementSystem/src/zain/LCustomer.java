/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
import java.sql.*;
import java.sql.ResultSet;
import project.Get;
import project.InsertUpdateDelete;
public class LCustomer {
    
    private int Cid;
    private String Fname;
    private String Lname;
    private String Cnic;

    public LCustomer() {
    }

    public LCustomer(int Cid, String Fname, String Lname, String Cnic) {
        this.Cid = Cid;
        this.Fname = Fname;
        this.Lname = Lname;
        this.Cnic = Cnic;
    }

    public int getCid() {
        return Cid;
    }

    public void setCid(int Cid) {
        this.Cid = Cid;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public String getCnic() {
        return Cnic;
    }

    public void setCnic(String Cnic) {
        this.Cnic = Cnic;
    }
    
    public void SetDataInDb()
    {
        
       Connection con=null;
       try
       {
           String Query="Insert into customer values ('"+Cid+"','"+Fname+"','"+Lname+"','"+Cnic+  "')";
           
           InsertUpdateDelete.setdata(Query, "Data Store in Customer");
           
       }
       catch(Exception e)
       {
           
       }
        
        
    }
    
}
