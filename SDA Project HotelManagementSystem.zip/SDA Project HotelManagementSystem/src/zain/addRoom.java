/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zain;

/**
 *
 * @author TOSHIBA Z30
 */
public class addRoom {
    
    private String RoomType;
    
    private String NoOfBed;
    private int RoomCharges;

    public addRoom() {
    }

    public addRoom(String RoomType, String NoOfBed, int RoomCharges) {
        this.RoomType = RoomType;
        this.NoOfBed = NoOfBed;
        this.RoomCharges = RoomCharges;
    }

    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String RoomType) {
        this.RoomType = RoomType;
    }

    public String getNoOfBed() {
        return NoOfBed;
    }

    public void setNoOfBed(String NoOfBed) {
        this.NoOfBed = NoOfBed;
    }

    public int getRoomCharges() {
        return RoomCharges;
    }

    public void setRoomCharges(int RoomCharges) {
        this.RoomCharges = RoomCharges;
    }
    public void print()
    {
        
        System.out.println(RoomType+" "+NoOfBed+" "+RoomCharges);
        
    }
}
