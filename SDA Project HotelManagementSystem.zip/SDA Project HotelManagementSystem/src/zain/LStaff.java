/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
public class LStaff {
private String name;
private int id;
private String cnic;
private String dept;
private String contactno;         
private int Mid;
private int Sal;

//Default Constructor
    public LStaff() {
    }
//Parametrized constructor
    public LStaff(String name, int id, String cnic, String dept, String contactno, int Mid, int Sal) {
        this.name = name;
        this.id = id;
        this.cnic = cnic;
        this.dept = dept;
        this.contactno = contactno;
        this.Mid = Mid;
        this.Sal = Sal;
    }
       // --------------Setter Getter----------------
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public int getMid() {
        return Mid;
    }

    public void setMid(int Mid) {
        this.Mid = Mid;
    }

    public int getSal() {
        return Sal;
    }

    public void setSal(int Sal) {
        this.Sal = Sal;
    }

}
