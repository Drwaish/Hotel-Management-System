/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
public class Lsignup {
    private String Fname;
    private String Lname;
     private String cnic;
    private String Email;
    private String gender;
    private String pwd;
    private int Cid;
    public Lsignup(){};  //default constructor
    
    
    //Parametrized Constructor
    public Lsignup(String Fname, String Lname, String cnic, String Email, String gender, String pwd,int Cid) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.cnic = cnic;
        this.Email = Email;
        this.gender = gender;
        this.pwd = pwd;
        this.Cid=Cid;
    }
    public void Copydata(Lsignup s1)
    {
        this.Fname=s1.Fname;
        this.Lname=s1.Lname;
        this.Email=s1.Email;
        this.cnic=s1.cnic;
        this.gender=s1.gender;
        this.Cid=s1.Cid;
        this.pwd=s1.pwd;
        
    }
    //utility function
public void setdata(String Fname1, String Lname1, String cnic1, String Email1, String gender1, String pwd1,int Cid1) {
        this.Fname = Fname1;
        this.Lname = Lname1;
        this.cnic = cnic1;
        this.Email = Email1;
        this.gender = gender1;
        this.pwd = pwd1;
        this.Cid=Cid1;
    }
    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getCid() {
        return Cid;
    }

    public void setCid(int Cid) {
        this.Cid = Cid;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    
    //for login Search it
    public void lookUp()
    {
        
        
    }
    
    
    
     public  void print()
    {
        System.out.println(Fname+" "+Lname+" "+cnic+" "+Email+" "+gender+" "+pwd);
        
        
    }
    public static void main(String args[])
    {
  
        // Declaring an array of student
       Lsignup[] arr;
       arr=new Lsignup[2];
       
      
      arr[0]=new Lsignup("Zain", "Ali", "12134","qwer@gmail", "male", "123",12);
      arr[1]=new Lsignup("nasir", "Ali", "12134","q12er@gmail", "male", "124",23);
System.out.println("Zain");
     arr[0].print();
     arr[1].print();
    
    
    
    
    }


}
