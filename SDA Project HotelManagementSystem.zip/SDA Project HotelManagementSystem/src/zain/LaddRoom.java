/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
public class LaddRoom {
    
     private String RoomType;
     private int RoomId;
     private String NoOfBed;
     private int RoomCharges;
    
    public LaddRoom(int RoomId,String RoomType,String NoOfBed, int RoomCharges) {
        this.RoomType = RoomType;
        this.RoomId = RoomId;
        this.NoOfBed = NoOfBed;
        this.RoomCharges = RoomCharges;
    }

    public int getRoomId() {
        return RoomId;
    }

    public void setRoomId(int RoomId) {
        this.RoomId = RoomId;
    }
    

    public LaddRoom() {
    }

   
public void setdata(String RoomType, int RoomId,String NoOfBed, int RoomCharges) {
        this.RoomType = RoomType;
        this.RoomId=RoomId;
        this.NoOfBed = NoOfBed;
        this.RoomCharges = RoomCharges;
    }
    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String RoomType) {
        this.RoomType = RoomType;
    }

    public String getNoOfBed() {
        return NoOfBed;
    }

    public void setNoOfBed(String NoOfBed) {
        this.NoOfBed = NoOfBed;
    }

    public int getRoomCharges() {
        return RoomCharges;
    }

    public void setRoomCharges(int RoomCharges) {
        this.RoomCharges = RoomCharges;
    }
    //Copy Data from one object to another object
    public void CopyData(LaddRoom l1)
    {
        this.RoomId=l1.RoomId;
        this.RoomType=l1.RoomType;
        this.NoOfBed=l1.NoOfBed;
        this.RoomCharges=l1.RoomCharges;
        
    }
    public void print()
    {
        
        System.out.println(RoomType+" "+RoomId+" "+NoOfBed+" "+RoomCharges);
        
    }
}
