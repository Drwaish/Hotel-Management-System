/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
import project.InsertUpdateDelete;
import project.Get;
import java.sql.*;
import javax.swing.JOptionPane;
import project.ConnectionProvider;
public class SystemClass {
    
  
    private static   int iR=0;
    private  static  int iB=0;
    private static   int  iS=0;
    private static   int iL=0;
    private static   int iSt=0;
   private LaddRoom[] R1=new LaddRoom[iR+5] ;  //for Room
    private LStaff[] St=new LStaff[iSt+5];
    private static LBooking []B1=new LBooking[iB+5];  //For Booking Details
     private static  Lsignup[] S1=new Lsignup[iS+5];    //For Signup
     private static  Llogin[] L1=new Llogin[iL+5];      //For Login details
     public static int getiSt() {   
        return iSt;
    }

    public static void setiSt(int iSt) {
        SystemClass.iSt = iSt;
    }

    public LStaff[] getSt() {
        return St;
    }

    //Default Construtor;
    public void setSt(LStaff[] St) {
        this.St = St;
    }

   
    
    
    public  int getiR() {
        return iR;
    }

    public void setiR(int iR) {
        this.iR = ++iR;
    }

    public  int getiB() {
        return iB;
    }
    public  void setiB(int iB) {
        this.iB = iB;
    }

    public  int getiS() {
        return iS;
    }

    public  void setiS(int iS) {
        this.iS = iS;
    }

    public  int getiL() {
        return iL;
    }

    //-------------------------------------------------------------------
    //getter and setter for arrays
    public  void setiL(int iL) {    
        this.iL = iL;
    }

    public LaddRoom[] getR1() {
        return R1;
    }

    public void setR1(LaddRoom[] R1) {
        this.R1 = R1;
    }

    public LBooking[] getB1() {
        return B1;
    }

    public void setB1(LBooking[] B1) {
        this.B1 = B1;
    }

    public Lsignup[] getS1() {
        return S1;
    }

    public void setS1(Lsignup[] S1) {
        this.S1 = S1;
    }

    public Llogin[] getL1() {
        return L1;
    }

    
    public void setL1(Llogin[] L1) {
        this.L1 = L1;
    }

   
    //---------------------------InsertData into database----------------------------------
     public void InsertRoomData()
    {
       
        for(int i=0;i<iR;i++)
        {
            String Query=null;
            Query="Insert into room values("+R1[i].getRoomId()+","+R1[i].getRoomType()+","+R1[i].getNoOfBed()+","+R1[i].getRoomCharges()+")";
            
            InsertUpdateDelete.setdata(Query, "Data Store in Room's Table");
          
            
        }
        
        iR=0; //again change the (iR)=0
    }
  
     public void InsertStaffData(LStaff st1)
     {
      String Query=null;
      Query="Insert into staff values('"+st1.getName()+"','"+st1.getId()+"','"+st1.getCnic()+"','"+st1.getDept()+"','"+st1.getContactno()+"','"+st1.getMid()+"','"+st1.getSal()+"')";
      InsertUpdateDelete.setdata(Query, "Data Store in Staff Table");
          
     }
     
     
        public void InsertRoomData1(LaddRoom r1)
    {
       
       
            String Query=null;
            Query="Insert into room values("+r1.getRoomId()+","+r1.getRoomType()+","+r1.getNoOfBed()+","+r1.getRoomCharges()+")";
            
            InsertUpdateDelete.setdata(Query, "Data Store in Room's Table");
          
            
        
        
       
    }   
        //------------------for  billing
        public String roomtype(int rid)
        {
            
             LoadRoomData();
            
            for(int i=0;i<iR;i++)
            {
            if(R1[i].getRoomId()==rid)
            {
                return R1[i].getRoomType();
            }
            }
            
            return null;
        }
        public int roomid(int cid)
        {
            LoadBookingData1();
            
            for(int i=0;i<iB;i++)
            {
                
                if(B1[i].getCid()==cid)
                {
                    
                    return B1[i].getRoomId();
                }
                
            }
            
            return 0;
        }
          public String date1(int cid)
        {
            LoadBookingData1();
            
            for(int i=0;i<iB;i++)
            {
                
                if(B1[i].getCid()==cid)
                {
                    
                    return B1[i].getDateofArrival();
                }
                
            }
            
            return null;
        }
    //---------------------End of billing
          

//---------------------Add Staff
          
           public void InsertStaff(LStaff st1)
           {
               if(st1!=null)
               {
                   String Query="Insert into staff values('"+st1.getName()+"','"+st1.getId()+"','"+st1.getCnic()+"','"+st1.getDept()+"','"+st1.getContactno()+"','"+st1.getMid()+"','"+st1.getSal()+"')";
                   
                   InsertUpdateDelete.setdata(Query, "Staff Information added");
                   
                   
               }
               
           }
          
          
          //---------------------End of Staff
            //---------------------Fire Staff
           
             public void FireStaff(int id)
             {
                 
                 if(id>0)
                 {
                     String Query="Delete from staff where Eid="+id;
                     InsertUpdateDelete.setdata(Query, "Staff Successfully Fire!!!");
                 }
                 else
                 {
                     JOptionPane.showMessageDialog(null, "Enter valid id");
                 }
             }
           
           //-------------------------------------
          
    public void InsertBookingData()
    {
          
           for(int i=0;i<iB;i++)
        {
            String Query=null;
            
            Query="Insert into bokking values("+B1[i].getBookingid()+","+B1[i].getRoomId()+","+B1[i].getDateofArrival()+")";
            InsertUpdateDelete.setdata(Query, "Data Store in Booking's Table");
            
            
        }
         
    }
    
     public void InsertBookingData1(int b1,int rid,int cid,String doa)
    {
          
         
            String Query=null;
            
            Query="Insert into booking values("+b1+","+rid+","+cid+","+doa+")";
            InsertUpdateDelete.setdata(Query, "Data Store in Booking's Table");
            
            
        
         //iB=0;  //again change the (iB)=0
    }
    public void InsertSignupData()
      {
          
           for(int i=0;i<iS;i++)
        {
            String Query=null;
            
            Query="Insert into signup values("+S1[i].getFname()+","+S1[i].getLname()+","+S1[i].getCnic()+","+S1[i].getEmail()+","+S1[i].getGender()+","+S1[i].getCid()+","+S1[i].getPwd()+")";
            InsertUpdateDelete.setdata(Query, "Data Store in Signup's Table");
            
            
        }
          iS=0;  //again change the (iS)=0
      }
      public boolean InsertSignupData1(Lsignup s1)
      {
         
           String Query=null;
       Query="Insert into signup values('"+s1.getFname()+"','"+s1.getLname()+"','"+s1.getCnic()+"','"+s1.getEmail()+"','"+s1.getGender()+"','"+s1.getCid()+"','"+s1.getPwd()+"')";
            
    InsertUpdateDelete.setdata(Query, "Data Store in Signup's Table");
            
            return true; 
       
         
      }
    public void InsertLoginData()
      {
          
        for(int i=0;i<iL;i++)
        {
            String Query=null;
            Query="Insert into login values ("+L1[i].getUsername()+","+L1[i].getPwd()+","+L1[i].getId()+")";
            InsertUpdateDelete.setdata(Query,"Data Store in Login table");
        }
        iL=0; //again change the (iL)=0
      }
     public void InsertLoginData1(Llogin l1)
      {
      
        
            String Query=null;
            Query="Insert into login values ('"+l1.getUsername()+"','"+l1.getPwd()+"','"+l1.getId()+"')";
            InsertUpdateDelete.setdata(Query,"Data Store in Login table");
        }
        
      
    //---------------------------Loading of data from database----------------------------------------------
    public void LoadRoomData()
    {
        
        //if(iR>0)
        {
        ResultSet rs=Get.getdata("Select * from room");
       int i=0;
        try
        {
         while(rs.next())  //Iterate loop until data not ended
        {
               int rid=rs.getInt(1);
               String Type=rs.getString(2);
               String NoB=rs.getString(3);
               int chr=rs.getInt(4);
               R1[i]=new LaddRoom(rid,Type,NoB,chr);
           i++;
               iR=iR+1;
            
        }
         //Help to avoid redundancy
         //InsertUpdateDelete.setdata("Delete from room", " ");
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error in loading Room data");
        
        }
        } 
        
           // else
           {
             //  JOptionPane.showMessageDialog(null,"No Data exist in Login Table");
           }
        
        
        
    }
    
    
   
     public void LoadBookingData()
     {
         
        //if(iB>0)
        {
       ResultSet rs1=Get.getdata("Select * from booking");
       System.out.println("Length of B1"+B1.length);
       int i=0;
        try
        {
            
         while(rs1.next())  //Iterate loop until data not ended
        {
          
           int num=(rs1.getInt(1));
           
          
            int rid=(rs1.getInt(2));
            
            int cid=(rs1.getInt(3));
            String doa=(rs1.getString(4));
             
           B1[i] =new LBooking(num,rid,cid,doa);
           B1[i].print();
           i++;
           iB=iB+1;
           System.out.println("iB"+iB);
            
        }
          //Help to avoid redundancy
        // InsertUpdateDelete.setdata("Delete  from booking", " ");
         
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error in loading Booking data");
        
        }
        
     }
     
        
         
         
     }
     public void AddBooking(int bid,int rid,int cid,String doa)
     {
         B1[iB++]=new LBooking(bid,rid,cid,doa);
         
         JOptionPane.showMessageDialog(null, "Room is booked.Your Room number is"+rid);
         
     }
     
     //----------------------------------delete krna ha
      public void LoadSignupData()
      {
          
        if(iS>0)
        {
       ResultSet rs=Get.getdata("Select * from signup");
       int i=0;
        try
        {
         while(rs.next())  //Iterate loop until data not ended
        {
          
           S1[i].setFname(rs.getString(1));
           S1[i].setLname(rs.getString(2));
           S1[i].setCnic(rs.getString(3));
           S1[i].setEmail(rs.getString(4));
           S1[i].setGender(rs.getString(5));
           S1[i].setCid(Integer.parseInt(rs.getString(6)));
           S1[i].setPwd(rs.getString(7));
            iS=iS+1;
            i++;
            
        }
          //Help to avoid redundancy
          InsertUpdateDelete.setdata("Delete from signup", " ");
        }
           catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error in loading Signup data");
        
        }
      }
      else
           {
               JOptionPane.showMessageDialog(null,"No Data exist in Signup Table");
           }
          
      }   
      
       public void LoadLoginData()
       {
          
            int i=0;
            String str=null;
            String str1=null;
            int num=0;
            ResultSet rs=Get.getdata("Select * from login");
        try
        {
         while(rs.next())  //Iterate loop until data not ended
        {
             
         str=rs.getString(1);//Username
         str1=rs.getString(2);//Password
         num=rs.getInt(3);  //Customer Id
       L1[i]=new Llogin(num,str,str1);
        iL=iL+1;
        i++;
            
        }
          //Help to avoid redundancy
          //InsertUpdateDelete.setdata("Delete * from login", " ");
        }
           catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error in loading login data");
        
        }
      
          
       }
    
    //----------------------Delete Room---------------------
    
       void deleteRoom(int id)
       {
           int flag=0;
                   int flag2=0;  //if room is book than you do not delete
            LoadBookingData1();
           for(int i=0;i<iB;i++)
           {
               if(B1[i].getRoomId()==id)
               {
                   flag=1;
               }
           }
           if(flag==0)
           {
               
              for(int i=0;i<iR;i++)
             {
                 
                 if(R1[i].getRoomId()==id)
                 {
                     flag2=1;
                     if(i<iR-1)  //for last room in 
                     {
                     for(int j=i;j<iR-1;j++)
                     {
                         R1[j].CopyData(R1[j+1]);
                     }
                     }
                     iR=iR-1;   //reduce the size no of rooms
                 }
             }
              //here we rewrite the data
              if(flag2==1)
              {
                  String Query1="DELETE FROM room where RoomId= "+id; //remove previous data
                  //System.out.println(Query1);
                  InsertUpdateDelete.setdata(Query1, null);

                  
                 
              }
              
                 if(flag2==0){
                     JOptionPane.showMessageDialog(null,"Room Not Exist");
              
                     
                     
                 }
               
           }
           else
           {
               
               JOptionPane.showMessageDialog(null,"Room is book.You can't delete");
           }
        }
           //----------------------End of deleteRoom--------------------
       
       //----------------------Signup--------------------
  /*     public  void CreateAccount(String Fname1, String Lname1, String cnic1, String Email1, String gender1, String pwd1,int Cid1)
       {
           S1[iS++].setdata(Fname1, Lname1, cnic1, Email1, gender1, pwd1, Cid1);
              
       }
       
*/   
       public  void addSignup(Lsignup s1)
       {
           
           S1[iS++].Copydata(s1);
           
       }
       //---------------------End of Sign up---------------------
       
       public  Llogin login1(String eml,String pwd)
       {
           
            LoadLoginData();
           for(int i=0;i<iL;i++)
           {
               System.out.println("Usrname"+L1[i].getUsername()+"Password"+L1[i].getPwd());

               
               if(L1[i].getUsername().equalsIgnoreCase(eml) && L1[i].getPwd().equalsIgnoreCase(pwd))
               {
                   
                   return L1[i];
               }
           }
           JOptionPane.showMessageDialog(null, "Username or Password incorrect");
           return null;
       }
       
       public void Addlogin(Llogin l1)
       {
           
         //  L1[++iL].CopyData(l1);
           
           
           
       }
       
       //-------------------------delete krny ha------------
     public void LoadBookingData1()
     {
     //rs1=null;
      
        try
        {
        Connection  con=ConnectionProvider.getcon();
        Statement st=con.createStatement();
        ResultSet rs1=st.executeQuery("Select * from booking");
    B1=new LBooking[2];
         //ResultSet rs1=Get.getdata("Select * from booking");
         
         //System.out.println(rs1.next());
         iB=0;
          
           // B1[0].setBookingid(num);
           // System.out.println(B1[0].getBookingid());
          int i=0;
           while(rs1.next())  //Iterate loop until data not ended
   
        {
        
            int num=(rs1.getInt(1));
           System.out.println("NUMber"+num);
          
            int rid=(rs1.getInt(2));
            System.out.println("roomid"+rid);
             int cid=(rs1.getInt(3));
              System.out.println("Custid"+cid);
             
            String doa=(rs1.getString(4));
             System.out.println("Arrival date"+doa);
            int l=B1.length;
             //if(l>0)
            B1[i]=new LBooking(num,rid,cid,doa);
             i++;
             iB=iB+1;
//System.out.println("Directt:"+num+" "+rid+" "+doa);
//System.out.println("INDirectt:"+B1[0].getBookingid()+" "+B1[0].getRoomId()+" "+B1[0].getDateofArrival());
            //B1[0].setRoomId(rid);
             //B1[0].setDateofArrival(doa);
              //B1[0].print();
          // iB=iB+1;
            
        }
          //Help to avoid redundancy
        // InsertUpdateDelete.setdata("Delete from booking", " Deleted");
         
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error in loading Booking data");
        
        }
        
    
        // System.out.println(B1[0].getBookingid()+" "+B1[0].getRoomId()+" "+B1[0].getDateofArrival());
         
     }
     
     public  boolean CheckBooking(LBooking b1)
     {
         System.out.println("IB"+iB);
         for(int i=0;i<iB;i++)
         {
             
             if(B1[i].getRoomId()==b1.getRoomId() && B1[i].getDateofArrival()==b1.getDateofArrival())
             {
                 
                 return true;
             }
             
         }
         
         
         return false;
         
     }
       public void printbooking()
       {
           System.out.println(iB);
           for(int i=0;i<iB;i++)
           B1[i].print();
       }
        public void printroom()
       {
           System.out.println(iR);
           for(int i=0;i<iR;i++)
           R1[i].print();
       }
       public static void main(String[] args)
       {
           
           
           
           
        SystemClass s1=new SystemClass(); 
         
         //  s1.LoadRoomData();
       // s1.printroom();
        //s1.deleteRoom(2);
        //s1.printroom();
         //s1.LoadBookingData();
         //s1.printbooking();
       // new Booking().setVisible(true);
         
         
           //s1.InsertSignupData1(L);
           
       // new Home().setVisible(true);
         //SystemClass s2=new SystemClass(); 
         //new recepitionist().setVisible(true);
         //s1.LoadBookingData1();
        // s1.printbooking();
       
       //s2.printbooking();
       }
}
