/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
    public class LBooking {
    private int RoomId;
    private int  Bookingid;
     private int Cid;
    private String DateofArrival;

    public LBooking(int Bookingid,int RoomId,int Cid, String DateofArrival) {
        this.RoomId= RoomId;
        this.Bookingid = Bookingid;
        this.Cid=Cid;
        this.DateofArrival = DateofArrival;
    }

    public int getCid() {
        return Cid;
    }

    public void setCid(int Cid) {
        this.Cid = Cid;
    }

    public int getRoomId() {
        return RoomId;
    }

    public void setRoomId(int RoomId) {
        this.RoomId = RoomId;
    }

   
   
    public int getBookingid() {
        return Bookingid;
    }

    public void setBookingid(int Bookingid) {
        this.Bookingid = Bookingid;
    }

    public String getDateofArrival() {
        return DateofArrival;
    }

    public void setDateofArrival(String DateofArrival) {
        this.DateofArrival = DateofArrival;
    }
    
    public void print()
    {
        
        System.out.println(Bookingid+"  "+RoomId +"  "+Cid+"  "+DateofArrival);
        
    }
    public void Copydata(int num1,int num2,int num3,String str)
    {
        this.Bookingid=num1;
        this.RoomId=num2;
        this.Cid=num3;
        this.DateofArrival=str;        
        
        
    }
    
}
