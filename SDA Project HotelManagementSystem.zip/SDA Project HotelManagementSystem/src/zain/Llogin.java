/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
public class Llogin {
private int id;
private String Username;  //usernam is email
private String pwd;

   
public Llogin(){}  //default constructor
    public Llogin(int id, String Username, String pwd) {
        this.id = id;
        this.Username = Username;
        this.pwd = pwd;
    }
    public void CopyData(Llogin l1)
    {
        this.Username=l1.Username;
        this.pwd=l1.pwd;
        this.id=l1.id;
       
        
    }
 public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

public void print()
{
    System.out.println(id+" "+Username+" "+pwd);
    
}
    
}

