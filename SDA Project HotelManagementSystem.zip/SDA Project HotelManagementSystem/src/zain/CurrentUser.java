/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOSHIBA Z30
 */
public class CurrentUser {
    
    private int Cid;
    private String eml;

    public CurrentUser(int Cid, String eml) {
        this.Cid = Cid;
        this.eml = eml;
    }

    public int getCid() {
        return Cid;
    }

    public void setCid(int Cid) {
        this.Cid = Cid;
    }

    public String getEml() {
        return eml;
    }

    public void setEml(String eml) {
        this.eml = eml;
    }
    
    public int Returnid()
    {
        int i=0;
        
        return i;
    }
    
    
}
